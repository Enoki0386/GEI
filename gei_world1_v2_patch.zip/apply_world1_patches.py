from pathlib import Path
import re

ROOT = Path('.')

def patch_file(path, patcher):
    path = ROOT / path
    if not path.exists():
        print(f"SKIP missing {path}")
        return
    text = path.read_text(encoding='utf-8')
    new = patcher(text)
    if new != text:
        path.write_text(new, encoding='utf-8')
        print(f"PATCHED {path}")
    else:
        print(f"UNCHANGED {path}")


def patch_gamedata(text):
    replacements = {
        'DisplayName = "Oeuf de depart"': 'DisplayName = "Starter Egg"',
        'Description = "Un petit pet qui augmente tes gains de Cash."': 'Description = "A tiny trash companion that boosts your Cash gains."',
        'Description = "Un pet tranquille qui ameliore ton sac."': 'Description = "A chill trash cat that improves your backpack."',
        'Description = "Un compagnon qui aide tes degats et tes gains."': 'Description = "A loyal recycler that boosts damage and Cash."',
        'Description = "Un slime etrange avec de gros bonus de recyclage."': 'Description = "A strange glowing slime with strong recycling bonuses."',
        'Description = "Un pet legendaire qui booste fortement ta progression."': 'Description = "A legendary raccoon that strongly boosts progression."',
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    if 'GameData.Admin = {' not in text:
        marker = 'GameData.Debug = {\n\tEnabled = false,\n\tStartingCash = 5000,\n\tStartingDiamonds = 500,\n\tStartingWaste = 0,\n\tToolDamageMultiplier = 1,\n}\n'
        insert = marker + '\nGameData.Admin = {\n\tUserIds = {\n\t\t[1990396002] = true,\n\t},\n}\n'
        text = text.replace(marker, insert)
    return text


def patch_petclient(text):
    if 'HatchCooldown = "Please wait for the egg to finish opening."' not in text:
        text = text.replace('InvalidEgg = "Invalid egg.",', 'InvalidEgg = "Invalid egg.",\n\t\tHatchCooldown = "Please wait for the egg to finish opening.",')
    if 'local hatchInProgress = false' not in text:
        text = text.replace('local currentHatcherPart = nil', 'local currentHatcherPart = nil\nlocal hatchInProgress = false')
    # Add a conservative client-side guard in the prompt callback if the current code matches the existing hatch request line.
    if 'if hatchInProgress then\n\t\t\t\treturn\n\t\t\tend' not in text:
        text = text.replace('local response = invokePetRemote(hatchEggRemote, STARTER_EGG_ID)', 'if hatchInProgress then\n\t\t\t\treturn\n\t\t\tend\n\t\t\thatchInProgress = true\n\t\t\tprompt.Enabled = false\n\t\t\tlocal response = invokePetRemote(hatchEggRemote, STARTER_EGG_ID)')
        text = text.replace('playHatchAnimation(response)\n\t\tend)', 'playHatchAnimation(response)\n\t\t\thatchInProgress = false\n\t\t\tprompt.Enabled = true\n\t\tend)')
    return text


def patch_petmanager(text):
    if 'local hatchCooldowns = {}' not in text:
        text = text.replace('local random = Random.new()', 'local random = Random.new()\nlocal hatchCooldowns = {}')
    if 'function PetManager.AdminGivePet' not in text:
        pattern = r'(local function refreshPlayer\(player\).*?\nend)\n\nfunction PetManager\.HatchEgg'
        insert = r'''\1

function PetManager.AdminGivePet(player, petId, variant)
	if type(petId) ~= "string" or not GameData.GetPet(petId) then
		return false, "Invalid pet"
	end
	if getInventoryCount(player) >= getMaxStorage(player) then
		return false, "Inventory full"
	end
	local petData = addPetToInventory(player, petId, variant or "Normal")
	if not petData then
		return false, "Could not add pet"
	end
	refreshPlayer(player)
	return true, "Pet given"
end

function PetManager.HatchEgg'''
        text = re.sub(pattern, insert, text, count=1, flags=re.S)
    if 'HatchCooldown' not in text[text.find('function PetManager.HatchEgg'):text.find('function PetManager.HatchEgg')+900]:
        text = text.replace('function PetManager.HatchEgg(player, eggId)\n', 'function PetManager.HatchEgg(player, eggId)\n\tlocal now = os.clock()\n\tif hatchCooldowns[player] and now - hatchCooldowns[player] < 3.2 then\n\t\treturn makeResponse(false, "HatchCooldown", { Pets = PetManager.GetSnapshot(player) })\n\tend\n\thatchCooldowns[player] = now\n')
    return text

patch_file('src/ReplicatedStorage/GameData.luau', patch_gamedata)
patch_file('src/StarterPlayer/StarterPlayerScripts/PetClient.client.luau', patch_petclient)
patch_file('src/ServerScriptService/Systems/PetManager.server.luau', patch_petmanager)
print('World 1 existing-file patches applied.')
